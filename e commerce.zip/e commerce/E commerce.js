document.addEventListener('DOMContentLoaded', () => {
    // Smooth scrolling for navigation links
    const navLinks = document.querySelectorAll('nav ul li a, .footer-links a');
    navLinks.forEach(link => {
      link.addEventListener('click', event => {
        if (link.getAttribute('href').startsWith('#')) {
          event.preventDefault();
          const targetId = link.getAttribute('href').substring(1);
          document.getElementById(targetId).scrollIntoView({
            behavior: 'smooth'
          });
        }
      });
    });
  
    // Form validation
    const reservationForm = document.querySelector('.reservation-form form');
    reservationForm.addEventListener('submit', event => {
      event.preventDefault();
      const name = document.querySelector('#name').value.trim();
      const email = document.querySelector('#email').value.trim();
      const message = document.querySelector('#message').value.trim();
      if (name === '' || email === '' || message === '') {
        alert('Please fill in all fields');
      } else {
        alert('Reservation request submitted successfully!');
        reservationForm.reset();
      }
    });
  
    const contactForm = document.querySelector('.contact-form form');
    contactForm.addEventListener('submit', event => {
      event.preventDefault();
      const name = document.querySelector('#contact-name').value.trim();
      const email = document.querySelector('#contact-email').value.trim();
      const message = document.querySelector('#contact-message').value.trim();
      if (name === '' || email === '' || message === '') {
        alert('Please fill in all fields');
      } else {
        alert('Message sent successfully!');
        contactForm.reset();
      }
    });
  
    // Image gallery lightbox effect
    const imageItems = document.querySelectorAll('.image-item img');
    imageItems.forEach(img => {
      img.addEventListener('click', () => {
        const lightbox = document.createElement('div');
        lightbox.classList.add('lightbox');
        document.body.appendChild(lightbox);
  
        const imgClone = img.cloneNode();
        lightbox.appendChild(imgClone);
  
        lightbox.addEventListener('click', () => {
          lightbox.remove();
        });
      });
    });
  });
  